<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Master extends CI_Controller {
	

}

/* End of file Master_setting.php */
/* Location: ./application/models/Master_setting.php */